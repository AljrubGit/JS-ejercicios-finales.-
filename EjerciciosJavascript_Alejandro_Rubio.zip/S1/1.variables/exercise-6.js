
let precio = (toy1.price + toy2.price)

console.log(`El precio de ambos juguetes es ${precio}`);