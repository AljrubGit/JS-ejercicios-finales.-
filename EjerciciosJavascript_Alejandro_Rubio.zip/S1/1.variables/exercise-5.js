let firstName = "Jon"; 
let lastName = "Snow"; 
let age = "24"; 

console.log(`Soy ${firstName} ${lastName}, tengo ${age} y me gustan los lobos.`);