for (let i; i <= 10; i++) {
    if (i < 10 ){
        console.log("Intentando dormir");
        } else {
       console.log("Dormido!");
    }
}


