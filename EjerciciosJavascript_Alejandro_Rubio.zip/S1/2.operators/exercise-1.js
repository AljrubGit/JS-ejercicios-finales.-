let resultado = 10 * 5; 
alert(resultado);