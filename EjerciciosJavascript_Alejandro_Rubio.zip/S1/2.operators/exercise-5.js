let x; 
let y = 10; 
let z = 5; 

x = y + z; 

console.log(x);