const RickAndMortyCharacters = ["Rick", "Beth", "Jerry", "Morty", "Summer", "Lapiz Lopez"];

RickAndMortyCharacters.pop(); 

console.log(RickAndMortyCharacters[0])
console.log(RickAndMortyCharacters[RickAndMortyCharacters.length - 1])
