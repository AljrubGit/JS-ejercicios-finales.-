<<<<<<< HEAD
Añade un evento click al botón `Call a cat` que haga una petición a `https://api.thecatapi.com/v1/images/search`. Pinta la imagen que recibas de la api y añade además un botón `Eliminar` que elimine la imagen del gato.

Puedes hacer click tantas veces como quieras en el botón `Call a cat`. De modo que si hago click 5 veces, pintaré 5 gatos
=======
Vamos a utilizar la api `https://ghibliapi.herokuapp.com/films` para pintar las peliculas en una galería.

Recoge los datos de la api y recorrelos para pintar en la web la imagen y el titulo de las peliculas.

Añade también clases a los elementos para poder darle estilos.
>>>>>>> 44257c1f97f0195d5ad7d5d683e2c2ca46cb13d5
