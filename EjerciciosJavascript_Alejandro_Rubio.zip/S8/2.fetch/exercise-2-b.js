const baseUrl = 'https://api.nationalize.io?name=';
const resultsContainer = document.querySelector('#results');

document.querySelector('#consultar').addEventListener('click', () => {
    const name = document.querySelector('input').value;
    const url = baseUrl + name;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            data.country.forEach(country => {
                const {country_id, probability} = country;
                const text = `El nombre ${name} tiene un ${probability.toFixed(2)}% de ser de ${country_id}.`;
                const newElement = document.createElement('p');
                newElement.textContent = text;
                resultsContainer.appendChild(newElement);
            });
        });
});