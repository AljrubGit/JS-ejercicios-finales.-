const youtube = streamers
  .filter((streamer) => streamer.gameMorePlayed.includes('Legends'))
  .map((streamer) => {
    if (streamer.age > 35) {
      streamer.gameMorePlayed = streamer.gameMorePlayed.toUpperCase();
    }
    return streamer;
  });

console.log(youtube);