const youtubers = streamers.filter(streamer => streamer.name.includes('u'));

console.log(youtubers);