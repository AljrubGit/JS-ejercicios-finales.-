const {title, gender, year} = game;

console.log(title);
console.log(gender);
console.log(year); 
