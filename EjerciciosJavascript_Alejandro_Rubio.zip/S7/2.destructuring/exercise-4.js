const {name, itv} = car;

console.log(name);
console.log(itv); 

const [año1, año2, año3] = itv; 

console.log(año1);
console.log(año2); 
console.log(año3);