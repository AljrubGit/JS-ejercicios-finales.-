const {name, race} = animalFunction();

console.log(name);
console.log(race); 