const numbers = [32, 21, 63, 95, 100, 67, 43];
const number = numbers.find(num => num === 100);
console.log(number);