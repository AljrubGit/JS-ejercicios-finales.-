const colors = ['rojo', 'azul', 'amarillo', 'verde', 'naranja']; 

const newColors = [...colors.slice(0, 2), ...colors.slice(3)];

console.log(newColors);