for (const destinos of placesToTravel){
    console.log(destinos);
}
