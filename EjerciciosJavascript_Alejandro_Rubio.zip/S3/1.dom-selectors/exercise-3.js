const parrafos = document.querySelector("p");
console.log(parrafos);