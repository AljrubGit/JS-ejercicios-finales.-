

const parrafo = document.createElement('p'); 
parrafo.textContent = '¡Soy dinámico!'; 
document.body.appendChild(parrafo); 

