const texto = document.querySelector(".fn-insert-here")
texto.textContent = 'Wubba Lubba dub dub'; 