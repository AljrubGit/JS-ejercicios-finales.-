const nuevoDiv = document.createElement("div");
nuevoDiv.innerHTML = "Esto es un div hecho con query selector";
document.body.appendChild(nuevoDiv);