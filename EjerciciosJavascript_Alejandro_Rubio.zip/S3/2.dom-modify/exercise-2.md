Inserta dinamicamente en un html un div que contenga una p con javascript.

