const btn = document.querySelector('#btnToClick');

btn.addEventListener('click', (evento) => {
  console.log('Enhorabuena', evento);
});
