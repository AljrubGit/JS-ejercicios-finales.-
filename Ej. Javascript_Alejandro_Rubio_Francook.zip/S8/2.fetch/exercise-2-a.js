const baseUrl = 'https://api.nationalize.io?name=';

         document.querySelector('#consultar').addEventListener('click', () => {
            const name = document.querySelector('input').value;
            const url = baseUrl + name

            fetch(url)
            .then(response => response.json())
            .then(data => console.log(data))
        } );


