function getAge() {
    const name = 'michael';
    fetch(`https://api.agify.io?name=${name}`)
        .then(response => response.json())
        .then(data => console.log(data))
        .catch(error => console.error(error))
};

