for (let i; i < 10; i++) {
    console.log(i);
    }