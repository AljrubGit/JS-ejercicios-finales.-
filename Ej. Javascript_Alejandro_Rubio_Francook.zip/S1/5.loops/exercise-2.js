for (let i; i <= 9; i++) {
    if (i / 2 === 0) {
        console.log(i)
    }
}