const RickAndMortyCharacters = ["Rick", "Beth", "Jerry", "Morty", "Summer", "Lapiz Lopez"];
RickAndMortyCharacters.splice(1, 1);
console.log(RickAndMortyCharacters);