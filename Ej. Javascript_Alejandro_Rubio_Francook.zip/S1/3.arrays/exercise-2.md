Cambia el primer elemento de cars a "Ford"

```js
const cars = ['Saab', 'Volvo', 'BMW'];
```