const cars = ["Saab", "Volvo", "BMW"];
alert(cars.length);