let resultado = 10 / 2; 
alert(resultado);