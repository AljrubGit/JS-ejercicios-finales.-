let resto = 15 / 9; 
alert(resto);