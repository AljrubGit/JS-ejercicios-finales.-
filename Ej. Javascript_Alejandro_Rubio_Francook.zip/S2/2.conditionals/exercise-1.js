for (let i = 0; i < alumns.length; i++) {
    const alumn = alumns[i];
    let numApproved = 0;

    if (alumn.T1) {
        numApproved++;
    }
    if (alumn.T2) {
        numApproved++;
    }
    if (alumn.T3) {
        numApproved++;
    }

    alumn.isApproved = numApproved >= 2;
}

console.log(alumns);