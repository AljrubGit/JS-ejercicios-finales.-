const jovenesLoleros = streamers.filter(streamer => streamer.gameMorePlayed === 'League of Legends' && streamer.age < 30);
console.log(jovenesLoleros);