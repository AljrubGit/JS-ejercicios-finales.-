const suma = (a = 10, b = 5) => {
    console.log(a + b);
  };
  
  suma(5)
  
  suma(4, 3)