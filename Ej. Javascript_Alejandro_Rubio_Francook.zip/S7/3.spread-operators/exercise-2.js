const copiaToy = {...toy}; 

console.log(copiaToy); 