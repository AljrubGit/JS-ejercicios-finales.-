const sumScores = exams.reduce((acc, exam) => acc + exam.score, 0);
const averageScore = sumScores / exams.length;

console.log(averageScore);