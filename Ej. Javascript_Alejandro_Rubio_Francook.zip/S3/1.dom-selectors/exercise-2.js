const parrafo = document.querySelector("#pillado");
console.log(parrafo); 
