const hazteConTodos = document.querySelectorAll(".pokemon")
console.log(hazteConTodos); 