const tercero = document.querySelectorAll('[data-function="testMe"]')[2];
console.log(tercero);