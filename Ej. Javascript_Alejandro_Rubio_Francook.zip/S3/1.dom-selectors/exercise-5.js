const superheroes = document.querySelectorAll(".testMe");
console.log(superheroes)