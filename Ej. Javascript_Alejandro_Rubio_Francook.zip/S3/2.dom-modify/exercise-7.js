const elementosAEliminar = document.querySelectorAll('.fn-remove-me');

elementosAEliminar.forEach((elemento) => {
  elemento.remove();
});
