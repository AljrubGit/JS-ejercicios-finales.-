const nuevoParrafo = document.createElement("p"); 
nuevoParrafo.innerHTML = "Párrafo hecho con querySelector"; 
document.body.appendChild(nuevoParrafo);