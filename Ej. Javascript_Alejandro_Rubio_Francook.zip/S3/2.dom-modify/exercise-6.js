const lista = document.createElement("ul")

for (let i = 0; i < apps.length; i++) {
const items = document.createElement("li")
items.textContent = apps[i];
lista.appendChild(items)
}

document.body.appendChild(lista); 