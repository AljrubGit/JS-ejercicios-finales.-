const nuevoDiv = document.createElement("div");
nuevoDiv.innerHTML = "Esto es un div hecho con query selector";
document.body.appendChild(nuevoDiv);


for (let i = 1; i <= 6; i++) {
    const p = document.createElement('p');
    p.textContent = `Este es el párrafo número ${i}`;
    nuevoDiv.appendChild(p);
}