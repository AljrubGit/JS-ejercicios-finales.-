const elementosAInsertar = document.querySelectorAll('.fn-insert-here');

elementosAInsertar.forEach((elemento) => {
  const parrafo = document.createElement('p');
  parrafo.textContent = 'Voy dentro!';
  elemento.appendChild(parrafo);
});