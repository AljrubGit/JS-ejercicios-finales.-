const input = document.querySelector('input');
    input.addEventListener('focus', function(event) {
      console.log('El valor del input es: ', event.target.value);
    });
